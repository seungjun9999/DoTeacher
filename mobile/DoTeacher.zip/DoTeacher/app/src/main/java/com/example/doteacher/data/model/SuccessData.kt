package com.example.doteacher.data.model

data class SuccessData(
    val success : Boolean
)