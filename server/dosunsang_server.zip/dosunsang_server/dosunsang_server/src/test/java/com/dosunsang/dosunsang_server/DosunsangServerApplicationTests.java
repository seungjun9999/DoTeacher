package com.dosunsang.dosunsang_server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DosunsangServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
