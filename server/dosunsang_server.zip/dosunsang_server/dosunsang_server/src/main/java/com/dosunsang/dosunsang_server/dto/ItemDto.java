package com.dosunsang.dosunsang_server.dto;

public class ItemDto {
    int x;
    int y;
    String name;

}
